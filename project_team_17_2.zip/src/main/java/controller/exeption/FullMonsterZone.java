package controller.exeption;

public class FullMonsterZone extends Exception{
public FullMonsterZone(){super("monster card zone is full");}
}
