package model;

public enum ActionsDoneInTurn {
    SET,
    CHANGE_POSITION,
    ATTACK,
    ENABLE_SUIJIN,

}
