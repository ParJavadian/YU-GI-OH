package model;

public enum SoundCondition {
    PLAY,
    PAUSE,
}
