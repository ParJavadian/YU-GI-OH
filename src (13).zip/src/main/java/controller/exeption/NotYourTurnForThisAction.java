package controller.exeption;

public class NotYourTurnForThisAction extends Exception{
public NotYourTurnForThisAction(){super("it’s not your turn to play this kind of moves");}
}
