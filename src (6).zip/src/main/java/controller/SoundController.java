//package controller;
//
//import javafx.scene.media.Media;
//import javafx.scene.media.MediaPlayer;
//
//import java.net.URISyntaxException;
//
//public class SoundController {
//
//    public void playWhenEatsDot() throws URISyntaxException {
//        Media media = new Media(getClass().getResource("/pacman_eatfruit.wav").toURI().toString());
//        MediaPlayer mediaPlayerForEatsDot = new MediaPlayer(media);
//        mediaPlayerForEatsDot.setCycleCount(1);
//        if (currentCondition.equals(Music.PLAY)) {
//            mediaPlayerForEatsDot.play();
//        }
//    }
//}
