package view;

public class LobbyView {
}
