package controller.exeption;

public class CardNotFoundFotController extends Exception{
public CardNotFoundFotController(){super("there is no card with this name");}
}
