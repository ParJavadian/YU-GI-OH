package controller.exeption;

public class NoCardFoundInThisPosition extends Exception{
public NoCardFoundInThisPosition(){super("no card found in the given position");}
}
