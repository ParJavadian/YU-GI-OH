package controller.exeption;

public class CanNotRitualSummon extends Exception{
    public CanNotRitualSummon(){super("there is no way you could ritual summon a monster");}
}
