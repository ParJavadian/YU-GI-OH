package controller.exeption;

public class UndonePreparationOfSpell extends Exception{
public UndonePreparationOfSpell(){super("preparations of this spell are not done yet");}
}
