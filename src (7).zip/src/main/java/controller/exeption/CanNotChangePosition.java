package controller.exeption;

public class CanNotChangePosition extends Exception{
public CanNotChangePosition(){super("you can’t change this card position");}
}
