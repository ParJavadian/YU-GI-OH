package model;

public enum BoardZone {
    MONSTERZONE,
    SPELLANDTRAPZONE,
    FIELDZONE,
    HAND,
    GRAVEYARD
}
