package model;
public enum Attribute {
    FIRE,
    DARK,
    EARTH,
    WATER,
    LIGHT,
    WIND
}
