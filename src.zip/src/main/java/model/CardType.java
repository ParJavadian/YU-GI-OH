package model;

public enum CardType {
    NORMAL,
    EFFECT,
    RITUAL
}
