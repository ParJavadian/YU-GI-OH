package controller.exeption;

public class InvalidSelection extends Exception {
    public InvalidSelection() {
        super("invalid selection");
    }
}
