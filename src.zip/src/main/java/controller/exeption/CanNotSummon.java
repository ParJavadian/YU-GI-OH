package controller.exeption;

public class CanNotSummon extends Exception{
public CanNotSummon(){super("you can’t summon this card");}
}
