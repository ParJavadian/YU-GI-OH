package controller;

import javafx.stage.Stage;
import model.User;

public class PreviousMenuControllerGraphic {

    public static void goBack(MenuTypesGraphic previousMenu, Stage stage){
        if (previousMenu.equals(MenuTypesGraphic.SCOREBOARDCONTROLLERDGRAPHIC)){

        }


    }
}
