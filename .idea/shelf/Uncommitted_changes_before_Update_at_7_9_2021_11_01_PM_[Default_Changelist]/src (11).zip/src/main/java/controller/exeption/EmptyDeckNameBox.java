package controller.exeption;

public class EmptyDeckNameBox extends Exception{
    public EmptyDeckNameBox(){super("no deck name was provided!");}
}


