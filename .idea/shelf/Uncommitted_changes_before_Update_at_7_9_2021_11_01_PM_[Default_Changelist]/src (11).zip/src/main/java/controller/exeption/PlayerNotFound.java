package controller.exeption;

public class PlayerNotFound extends Exception{
public PlayerNotFound(){super("there is no player with this username");}
}
