package controller.exeption;

public class MustRitualSummon extends Exception{
public MustRitualSummon(){super("you should ritual summon right now");}
}
