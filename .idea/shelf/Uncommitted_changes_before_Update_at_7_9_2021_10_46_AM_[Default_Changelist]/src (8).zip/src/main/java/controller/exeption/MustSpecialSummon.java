package controller.exeption;

public class MustSpecialSummon extends Exception{
    public MustSpecialSummon(){super("you should special summon right now");}

}
