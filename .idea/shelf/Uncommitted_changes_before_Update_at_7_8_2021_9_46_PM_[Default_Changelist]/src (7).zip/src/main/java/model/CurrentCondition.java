package model;

public enum  CurrentCondition {
    MAIN_NO_CARD_SELECTED,

}
