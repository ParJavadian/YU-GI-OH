package controller.exeption;

public class FullSpellZone extends Exception{
public FullSpellZone(){super("spell card zone is full");}
}
