package view;

public class BoardGamePlayerTwo {
}
