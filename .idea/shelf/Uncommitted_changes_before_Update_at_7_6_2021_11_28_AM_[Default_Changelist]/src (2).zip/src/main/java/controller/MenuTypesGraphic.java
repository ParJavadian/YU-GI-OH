package controller;

public enum MenuTypesGraphic {
    SIGNUPCONTROLLERGRAPHIC, //to previous menu controller naneveshtam.
    SCOREBOARDCONTROLLERDGRAPHIC,
    PROFILECONTROLLERGRAPHIC,
    LOGINCONTROLLERGRAPHIC,  //to previous menu controller naneveshtam.
    CHANGEPASSWORDCONTROLLERGRAPHIC,
    CHANGENICKNAMECONTROLLERGRAPHIC,
    MAINCONTROLLERGRAPHIC
}
