package controller.exeption;

public class IsNotSpell extends Exception{
public IsNotSpell(){super("activate effect is only for spell cards.");}
}
