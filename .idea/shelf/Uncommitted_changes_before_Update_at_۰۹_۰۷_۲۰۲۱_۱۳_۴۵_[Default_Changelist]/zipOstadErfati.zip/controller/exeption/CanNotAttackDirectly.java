package controller.exeption;

public class CanNotAttackDirectly extends Exception{
    public CanNotAttackDirectly(){super("you can’t attack the opponent directly");}
}
