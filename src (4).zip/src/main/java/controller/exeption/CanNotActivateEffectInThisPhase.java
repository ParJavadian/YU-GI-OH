package controller.exeption;

public class CanNotActivateEffectInThisPhase extends Exception{
public CanNotActivateEffectInThisPhase(){super("you can’t activate an effect in this phase");}
}
