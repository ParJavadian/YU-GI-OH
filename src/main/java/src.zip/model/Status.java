package model;
public enum Status {
    UNLIMITED,
    LIMITED
}
