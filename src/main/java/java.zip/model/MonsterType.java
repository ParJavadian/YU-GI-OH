package model;

public enum MonsterType {
    WARRIOR,
    BEAST_WARRIOR,
    FIEND,
    AQUA,
    BEAST,
    PYRO,
    SPELLCASTER,
    THUNDER,
    DRAGON,
    MACHINE,
    ROCK,
    INSECT,
    CYBERSE,
    FAIRY,
    SEA_SERPENT
}
