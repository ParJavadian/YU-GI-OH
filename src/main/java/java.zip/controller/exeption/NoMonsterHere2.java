package controller.exeption;

public class NoMonsterHere2 extends Exception {
//TODO nemidunam chie!
}
