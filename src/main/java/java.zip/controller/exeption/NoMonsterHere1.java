package controller.exeption;

public class NoMonsterHere1 extends Exception {
    //TODO doroste?!
    public NoMonsterHere1() {
        super("there no monsters one this address");
    }
}
