package controller;

import javafx.animation.Transition;
import javafx.scene.image.Image;

public class SwordController extends Transition {


    @Override
    protected void interpolate(double v) {
        int frame = (int) Math.floor(v * 6);
        imageView.setImage( new Image("/images/sword/" + frame + ".png"));
    }
}
